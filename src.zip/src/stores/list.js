import { defineStore } from "pinia";
import { ref } from "vue";
import { readListWorkbook } from "@/services/list-excel-reader";
import { buildListWorkbookBuffer } from "@/services/list-excel-writer";

let _uidCounter = 0;
function genUid() {
  return ++_uidCounter;
}

function normalizeProductId(value) {
  return String(value ?? "").trim();
}

export const useListStore = defineStore("list", () => {
  const filePath = ref("");
  const records = ref([]);
  const columnOrder = ref([]);
  const hiddenColumns = ref([]);
  const loading = ref(false);
  const error = ref("");

  async function loadFromBuffer(buffer, p) {
    loading.value = true;
    error.value = "";
    if (p)
      filePath.value = p;
    try {
      const { columnOrder: order, hiddenColumns: hidden, records: rows } = await readListWorkbook(buffer);
      records.value = rows.map(r => ({
        ...r,
        _uid: genUid(),
      }));
      columnOrder.value = order;
      hiddenColumns.value = hidden || [];
    }
    catch (e) {
      error.value = e.message;
    }
    finally {
      loading.value = false;
    }
  }

  async function getExportBuffer() {
    return await buildListWorkbookBuffer(records.value, columnOrder.value, hiddenColumns.value);
  }

  function withUids(rows) {
    return rows.map(row => ({
      ...row,
      _uid: genUid(),
    }));
  }

  function addRecords(skuRows) {
    records.value.push(...withUids(skuRows));
    syncColumnOrder();
  }

  function replaceRecordsByProductId(productId, skuRows) {
    const target = normalizeProductId(productId);
    if (!target) {
      addRecords(skuRows);
      return;
    }

    const firstIndex = records.value.findIndex(row => normalizeProductId(row["商品ID"]) === target);
    if (firstIndex < 0) {
      addRecords(skuRows);
      return;
    }

    records.value = [
      ...records.value.slice(0, firstIndex),
      ...withUids(skuRows),
      ...records.value.slice(firstIndex).filter(row => normalizeProductId(row["商品ID"]) !== target),
    ];
    syncColumnOrder();
  }

  function removeRecord(index) {
    records.value.splice(index, 1);
  }

  function moveRecordToTop(index) {
    if (index <= 0)
      return;
    const [moved] = records.value.splice(index, 1);
    records.value.unshift(moved);
  }

  function moveRecordToBottom(index) {
    if (index >= records.value.length - 1)
      return;
    const [moved] = records.value.splice(index, 1);
    records.value.push(moved);
  }

  function updateRecord(index, data) {
    records.value[index] = {
      ...records.value[index],
      ...data,
    };
  }

  function syncColumnOrder() {
    if (!records.value.length) {
      columnOrder.value = [];
      return;
    }
    const existing = new Set(columnOrder.value);
    const allKeys = new Set();
    for (const row of records.value) {
      for (const k of Object.keys(row)) {
        if (k !== "_uid")
          allKeys.add(k);
      }
    }
    const merged = [...columnOrder.value.filter(k => allKeys.has(k))];
    for (const k of allKeys) {
      if (!existing.has(k))
        merged.push(k);
    }
    columnOrder.value = merged;
    hiddenColumns.value = hiddenColumns.value.filter(k => allKeys.has(k));
  }

  function clear() {
    filePath.value = "";
    records.value = [];
    columnOrder.value = [];
    hiddenColumns.value = [];
  }

  return {
    addRecords,
    clear,
    columnOrder,
    error,
    filePath,
    getExportBuffer,
    hiddenColumns,
    loadFromBuffer,
    loading,
    moveRecordToBottom,
    moveRecordToTop,
    records,
    removeRecord,
    replaceRecordsByProductId,
    syncColumnOrder,
    updateRecord,
  };
});
