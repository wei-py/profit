import { defineStore } from "pinia";
import { computed, ref } from "vue";
import { readWorkbookBuffer } from "@/services/excel-reader";
import { buildWorkbookBuffer } from "@/services/excel-writer";
import {
  buildCascadeSteps,
  getCascadeDefaultValue,
  getChildGroups as getCascadeChildGroups,
  getEnabledOptionItems,
  groupHasDescendants as hasOptionGroupDescendants,
  normalizeOptionGroup,
} from "@/utils/optionCascade";

export const useConfigStore = defineStore("config", () => {
  const filePath = ref("");
  const workbook = ref(null);
  const loading = ref(false);
  const error = ref("");

  // 核心数据（key 名与 Excel sheet 名一致）
  const 国家平台 = ref([]);
  const 计算字段 = ref([]);
  const 选项组 = ref([]);
  const 选项值 = ref([]);
  const 计算模板 = ref([]);
  const 费用规则 = ref([]);
  const 模板参数 = ref([]);
  const lookupTables = ref({});
  const 国家平台ColOrder = ref([]);
  const 国家平台HiddenCols = ref([]);

  const isRemote = ref(false);
  const remoteUrl = ref("");

  const loaded = computed(() => 国家平台.value.length > 0);

  /** @param {ArrayBuffer} buffer @param {string} [p] @param {{ remote?: boolean, remoteUrl?: string }} [opts] */
  async function loadFromBuffer(buffer, p, opts = {}) {
    loading.value = true;
    error.value = "";
    if (p)
      filePath.value = p;
    isRemote.value = opts.remote || false;
    if (opts.remoteUrl)
      remoteUrl.value = opts.remoteUrl;
    try {
      const config = readWorkbookBuffer(buffer);
      国家平台.value = config["国家平台"] || [];
      计算字段.value = config["计算字段"] || [];
      选项组.value = (config["选项组"] || []).map(normalizeOptionGroup);
      选项值.value = config["选项值"] || [];
      计算模板.value = config["计算模板"] || [];
      费用规则.value = config["费用规则"] || [];
      模板参数.value = config["模板参数"] || [];
      lookupTables.value = config.lookupTables || {};
      国家平台ColOrder.value = config.国家平台ColOrder || [];
      国家平台HiddenCols.value = config.国家平台HiddenCols || [];
      sync国家平台ColOrder();
      workbook.value = buffer;
    }
    catch (e) {
      error.value = e.message;
    }
    finally {
      loading.value = false;
    }
  }

  async function getExportBuffer() {
    sync国家平台ColOrder();
    return await buildWorkbookBuffer({
      lookupTables: lookupTables.value,
      国家平台: 国家平台.value,
      国家平台ColOrder: 国家平台ColOrder.value,
      国家平台HiddenCols: 国家平台HiddenCols.value,
      模板参数: 模板参数.value,
      计算字段: 计算字段.value,
      计算模板: 计算模板.value,
      费用规则: 费用规则.value,
      选项值: 选项值.value,
      选项组: 选项组.value,
    });
  }

  function sync国家平台ColOrder() {
    if (!国家平台.value.length) {
      国家平台ColOrder.value = [];
      国家平台HiddenCols.value = [];
      return;
    }
    const existing = new Set(国家平台ColOrder.value);
    const allKeys = new Set();
    for (const row of 国家平台.value) {
      for (const k of Object.keys(row)) {
        if (k)
          allKeys.add(k);
      }
    }
    const merged = [...国家平台ColOrder.value.filter(k => allKeys.has(k))];
    for (const k of allKeys) {
      if (!existing.has(k))
        merged.push(k);
    }
    国家平台ColOrder.value = merged;
    国家平台HiddenCols.value = 国家平台HiddenCols.value.filter(k => allKeys.has(k));
  }

  // ── 便捷查询 ──

  /** 某国家下的启用模板 */
  function getTemplatesByCountry(cpId) {
    return 计算模板.value.filter(
      t => t.所属国家平台 === cpId && (t.启用 === "是" || t.启用 === "TRUE"),
    );
  }

  /** 某模板下的费用规则（按计算顺序排序） */
  function getFeeRulesByTemplate(templateId) {
    return 费用规则.value
      .filter(r => r.所属模板 === templateId)
      .sort((a, b) => Number(a.计算顺序) - Number(b.计算顺序));
  }

  /** 某国家下的字段 */
  function getFieldsByCountry(cpId) {
    return 计算字段.value.filter(f => f.所属国家平台 === cpId);
  }

  /** 某国家下的选项组 */
  function getOptionGroupsByCountry(cpId) {
    return 选项组.value.filter(g => g.所属国家平台 === cpId);
  }

  /** 某选项组下的选项值 */
  function getOptionItemsByGroup(groupId) {
    return 选项值.value.filter(i => i.所属分组 === groupId);
  }

  /** 某选项组下的启用选项值（按排序字段排序） */
  function getEnabledOptionItemsByGroup(groupId) {
    return getEnabledOptionItems(选项值.value, groupId);
  }

  /** 某选项组的直接子组；传入 parentOptionValue 时只返回匹配该父选项的子组。 */
  function getChildGroups(groupId, parentOptionValue = "") {
    return getCascadeChildGroups(选项组.value, groupId, parentOptionValue);
  }

  function groupHasDescendants(groupId) {
    return hasOptionGroupDescendants(选项组.value, groupId);
  }

  function buildOptionCascade(groupId, pathValues = []) {
    return buildCascadeSteps({
      optionGroups: 选项组.value,
      optionItems: 选项值.value,
      pathValues,
      rootGroupId: groupId,
    });
  }

  function getOptionCascadeDefault(groupId) {
    return getCascadeDefaultValue({
      optionGroups: 选项组.value,
      optionItems: 选项值.value,
      rootGroupId: groupId,
    });
  }

  /** 构建选项组树（含子组递归），返回顶级组列表 */
  function getGroupTree(countryId) {
    const all = 选项组.value.filter(g => g.所属国家平台 === countryId);
    const roots = all.filter(g => !g.父级编号);
    function attachChildren(parent) {
      const children = all.filter(g => g.父级编号 === parent.编号);
      parent.children = children.map(c => attachChildren({ ...c }));
      return parent;
    }
    return roots.map(r => attachChildren({ ...r }));
  }

  /** 按字段键查字段定义 */
  function getField(fieldKey, cpId) {
    return 计算字段.value.find(f => f.字段键 === fieldKey && f.所属国家平台 === cpId);
  }

  /** 某模板的参数默认值 */
  function getTemplateParams(templateId) {
    return 模板参数.value.filter(p => p.模板编号 === templateId);
  }

  /** 某国家下的启用字段 */
  function getEnabledFieldsByCountry(cpId) {
    return 计算字段.value.filter(
      f => f.所属国家平台 === cpId && (f.启用 === "是" || f.启用 === "TRUE" || !f.启用),
    );
  }

  function clear() {
    filePath.value = "";
    workbook.value = null;
    isRemote.value = false;
    国家平台.value = [];
    计算字段.value = [];
    选项组.value = [];
    选项值.value = [];
    计算模板.value = [];
    费用规则.value = [];
    模板参数.value = [];
    国家平台ColOrder.value = [];
    lookupTables.value = {};
  }

  return {
    buildOptionCascade,
    clear,
    error,
    filePath,
    getChildGroups,
    getEnabledOptionItemsByGroup,
    getEnabledFieldsByCountry,
    getExportBuffer,
    getFeeRulesByTemplate,
    getField,
    getFieldsByCountry,
    getGroupTree,
    getOptionGroupsByCountry,
    getOptionCascadeDefault,
    getOptionItemsByGroup,
    getTemplateParams,
    getTemplatesByCountry,
    groupHasDescendants,
    isRemote,
    loaded,
    loadFromBuffer,
    loading,
    lookupTables,
    remoteUrl,
    sync国家平台ColOrder,
    workbook,
    国家平台,
    国家平台ColOrder,
    国家平台HiddenCols,
    模板参数,
    计算字段,
    计算模板,
    费用规则,
    选项值,
    选项组,
    setFilePath: (p) => {
      filePath.value = p;
    },
  };
});
